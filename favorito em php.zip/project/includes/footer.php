<footer class="footer">
    <div class="footer-content">
        <div class="footer-copyright">
            &copy; <?php echo date('Y'); ?> SISCONF. Todos os direitos reservados.
        </div>
        <div class="footer-links">
            <a href="politica-privacidade" class="footer-link">Política de Privacidade</a>
            <a href="termos-uso" class="footer-link">Termos de Uso</a>
            <a href="suporte" class="footer-link">Suporte</a>
        </div>
    </div>
</footer>